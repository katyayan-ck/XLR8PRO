@extends(backpack_view('blank'))

@php
use App\Services\OrgService;
@endphp

@section('title', 'Quotation Form')

@push('after_styles')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
<style>
    @media print {
        select {
            appearance: none !important;
            -webkit-appearance: none !important;
            -moz-appearance: none !important;

            background: transparent !important;
            background-image: none !important;

            border: none !important;
            outline: none !important;

            padding-right: 0 !important;
        }


        .no-print {
            display: none !important;
        }

        body {
            margin: 0;
            padding: 0;
        }

        .quotation-sheet {

            width: 100%;





            margin: 0;

            padding: 2mm;

            box-shadow: none;

            border: 1px solid #000;

            display: flex;
            flex-direction: column;
        }

    }

    .quotation-sheet {

        background: #fff;

        border: 1px solid #000;

        padding: 15px;

    }


    .bill-table {

        width: 100%;

        border-collapse: collapse;

    }



    .bill-table .title {

        background: #f2f2f2;

        font-weight: bold;

    }



    .bill-table input:focus {

        outline: none;

    }

    .bill-table select {

        border: none;

        width: 100%;

        background: transparent;

    }

    .bill-table select:focus {

        outline: none;

    }

    .bill-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 15px;
    }

    .bill-table td {
        border: 1px solid #000;
        padding: 2px 5px;

        height: 26px;

        font-size: 10px;
        vertical-align: middle;
    }

    .bill-table .title {
        background: #f2f2f2;
        font-weight: 600;
        white-space: nowrap;
    }

    .bill-table input {
        border: none !important;
        box-shadow: none !important;
        background: transparent !important;
        padding: 2px;
    }


    /* Hide Backpack UI */

    .page-header {
        display: none !important;
    }

    .navbar {
        display: none !important;
    }

    .main-header {
        display: none !important;
    }

    .sidebar {
        display: none !important;
    }

    .app-footer {
        display: none !important;
    }

    .breadcrumb {
        display: none !important;
    }

    .content-header {
        display: none !important;
    }

    .wrapper {
        padding-top: 0 !important;
    }

    .main-body {
        margin-top: 0 !important;
    }

    @media print {

        /* Form me select hide */
        #accessories+.select2-container {
            display: none !important;
        }

        /* Sirf text dikhao */
        #accessories_print {
            display: block !important;
            white-space: normal;
            word-break: break-word;
            font-size: 11px;
            line-height: 15px;
        }

    }

    .row.align-items-stretch {
        align-items: stretch;
    }

    .note-table {
        flex: 1;
    }

    .note-table td {
        vertical-align: top;
    }

    .note-box {
        margin-top: 12px;
    }

    .quotation-table {
        margin-bottom: auto;
    }

    .quotation-table td,
    .quotation-table th {

        padding: 3px 3px;

        font-size: 10px;

        border: 1px solid #000;

    }

    .quotation-table input {

        width: 100%;

        border: none;

        background: transparent;

    }

    .quotation-table select {

        width: 100%;

        border: none;

        background: transparent;

    }
</style>

@endpush

@section('content')

<div class="quotation-form">
    <div class="container-fluid">

        <div class="card shadow-sm mb-3">

            <div class="card-body p-3">

                <div class="row align-items-center">

                    <div class="col-md-2 text-center">

                        <img src="{{ asset('images/bikaner_logo.jpg') }}" style="height:75px;">

                    </div>

                    <div class="col-md-10 text-center">

                        <h2 class="mb-1 fw-bold">
                            BIKANER MOTORS PRIVATE LIMITED
                        </h2>

                        <div style="font-size:14px">

                            <strong>Regd. Office :</strong>

                            Sunderi Chhabil Mansion,
                            NH-11,
                            Jaipur Road,
                            P.O. Udasar,
                            Bikaner-334022

                        </div>

                        <div style="font-size:14px">

                            <strong>Branch Office :</strong>

                            6th KM Stone,
                            Ratangarh Road,
                            Churu (Raj.)

                        </div>

                        <h4 class="mt-2 text-uppercase">

                            Vehicle Quotation

                        </h4>

                    </div>

                </div>

            </div>

        </div>

        <form method="POST" action="{{ route('quotation.store') }}" enctype="multipart/form-data">
            @csrf
            <div class="quotation-sheet">

                <div class="form-section">

                    {{-- ================= Customer Details ================= --}}
                    <table class="bill-table mb-3">

                        <tr>
                            <td class="title" width="18%">Enquiry No</td>
                            <td width="32%">
                                <input type="text" class="form-control border-0 shadow-none"
                                    value="{{ optional($selectedEnquiry)->enquiry_no }}" readonly>

                                <input type="hidden" name="enquiry_no"
                                    value="{{ optional($selectedEnquiry)->enquiry_no }}">
                            </td>

                            <td class="title" width="18%">Customer Name</td>
                            <td width="32%">
                                <input type="text" id="customer_name" class="form-control border-0 shadow-none"
                                    value="{{ optional($selectedEnquiry)->full_name }}" readonly>
                            </td>
                        </tr>

                        <tr>
                            <td class="title">Mobile Number</td>
                            <td>
                                <input type="text" id="mobile" class="form-control border-0 shadow-none"
                                    value="{{ optional($selectedEnquiry)->mobile }}" readonly>
                            </td>


                        </tr>

                    </table>

                    {{-- ================= Vehicle Details ================= --}}

                    <table class="bill-table mb-3">

                        <tr>
                            <td class="title" width="18%">Segment</td>
                            <td width="32%">
                                <input type="text" class="form-control border-0 shadow-none"
                                    value="{{ optional(optional($selectedEnquiry)->segment)->name }}" readonly>

                                <input type="hidden" name="segment_code"
                                    value="{{ optional($selectedEnquiry)->segment_code }}">
                            </td>

                            <td class="title" width="18%">Model</td>
                            <td width="32%">
                                <input type="text" class="form-control border-0 shadow-none"
                                    value="{{ optional(optional($selectedEnquiry)->model)->name }}" readonly>

                                <input type="hidden" name="model_code"
                                    value="{{ optional($selectedEnquiry)->model_code }}">
                            </td>
                        </tr>

                        <tr>
                            <td class="title">Variant</td>
                            <td>
                                <input type="text" class="form-control border-0 shadow-none"
                                    value="{{ optional(optional($selectedEnquiry)->variant)->display_name }}" readonly>

                                <input type="hidden" name="variant_code"
                                    value="{{ optional($selectedEnquiry)->variant_code }}">
                            </td>

                            <td class="title">Color</td>
                            <td>
                                <input type="text" class="form-control border-0 shadow-none"
                                    value="{{ optional(optional($selectedEnquiry)->color)->name }}" readonly>

                                <input type="hidden" name="color_code"
                                    value="{{ optional($selectedEnquiry)->color_code }}">
                            </td>
                        </tr>

                    </table>

                    <table class="bill-table quotation-table">

                        <tr style="background:#d9d9d9;font-weight:bold;text-align:center;">
                            <th width="16%">PRICE DETAILS</th>
                            <th width="34%">AMOUNT</th>
                            <th width="22%">DISCOUNT DETAILS</th>
                            <th width="28%">AMOUNT</th>
                        </tr>
                        <tr>
                            <td class="title">Ex Showroom Price</td>
                            <td>
                                <input name="ex_showroom_price" id="ex_showroom_price" class="numeric-only"
                                    placeholder="0.00">
                            </td>
                            <td class="title discount-title">OEM Scheme / CSD Discount</td>
                            <td class="discount-value">
                                <input type="text" name="oem_scheme_discount" id="oem_scheme_discount"
                                    class="numeric-only" placeholder="0.00">
                            </td>

                        </tr>
                        <tr>
                            <td class="title">Insurance</td>

                            <td>

                                <select name="policy_type" id="policy_type">

                                    <option value="">Select</option>

                                    @foreach($insurance_type_map as $key=>$value)

                                    <option value="{{ $key }}">
                                        {{ $value }}
                                    </option>

                                    @endforeach

                                </select>

                            </td>
                            <td class="title discount-title">
                                PPF Discount
                            </td>

                            <td class="discount-value">
                                <input type="text" name="ppf_discount" id="ppf_discount" class="numeric-only"
                                    placeholder="0.00">
                            </td>

                        </tr>
                        <tr>
                            <td class="title">

                                Registration

                            </td>

                            <td>

                                <select name="registration_type" id="registration_type">

                                    <option value="">Select</option>

                                    @foreach($registration_type_map as $key=>$value)

                                    <option value="{{ $key }}">

                                        {{ $value }}

                                    </option>

                                    @endforeach

                                </select>

                            </td>
                            <td class="title discount-title">
                                Dealer Discount
                            </td>

                            <td class="discount-value">
                                <input type="text" name="dealer_discount" id="dealer_discount" class="numeric-only"
                                    placeholder="0.00">
                            </td>


                        </tr>
                        <tr>
                            <td class="title">

                                Accessories

                            </td>

                            <td>

                                <select name="accessories[]" id="accessories" multiple>
                                    @foreach($accessoryList as $accessory)
                                    <option value="{{ $accessory->part_no }}" data-price="{{ $accessory->ndp }}">
                                        {{ $accessory->item }}
                                        (₹{{ number_format($accessory->ndp,2) }})
                                    </option>
                                    @endforeach
                                </select>

                                <span id="accessories_print" style="display:none;"></span>

                            </td>
                            <td class="title discount-title">
                                Corporate Discount
                            </td>

                            <td class="discount-value">
                                <input type="text" name="corporate_discount" id="corporate_discount"
                                    class="numeric-only" placeholder="0.00">
                            </td>

                        </tr>
                        <tr>
                            <td class="title">

                                Accessories Amount

                            </td>

                            <td>

                                <input id="accessories_amount" name="accessories_amount" readonly value="0.00">

                            </td>
                            <td class="title discount-title">
                                Exchange Bonus
                            </td>

                            <td class="discount-value">
                                <input type="text" name="exchange_bonus" id="exchange_bonus" class="numeric-only"
                                    placeholder="0.00">
                            </td>



                        </tr>
                        <tr>
                            <td class="title">

                                Maxicare

                            </td>

                            <td>

                                <input id="maxicare" name="maxicare" class="numeric-only">

                            </td>
                            <td class="title discount-title">
                                Accessories Discount
                            </td>

                            <td class="discount-value">
                                <input type="text" name="accessories_discount" id="accessories_discount"
                                    class="numeric-only" placeholder="0.00">
                            </td>


                        </tr>
                        <tr>

                            <td class="title">

                                VLTD Device (GPS)

                            </td>

                            <td>

                                <input id="vltd_device" name="vltd_device" class="numeric-only">

                            </td>
                            <td class="title discount-title">
                                Ceramic Discount
                            </td>

                            <td class="discount-value">
                                <input type="text" name="ceramic_discount" id="ceramic_discount" class="numeric-only"
                                    placeholder="0.00">
                            </td>



                        </tr>
                        <tr>
                            <td class="title">

                                Coating

                            </td>

                            <td>

                                <select id="coating" name="coating">

                                    <option value="">Select</option>

                                    <option value="Ceramic">

                                        Ceramic

                                    </option>

                                    <option value="Graphene">

                                        Graphene

                                    </option>

                                    <option value="No Coating">

                                        No Coating

                                    </option>

                                </select>

                            </td>
                            <td class="title discount-title" id="fame_title">Fame Subsidy (LMM)</td>
                            <td class="discount-value" id="fame_cell">
                                <input type="text" name="fame_subsidy" id="fame_subsidy" class="numeric-only"
                                    placeholder="0.00">
                            </td>



                        </tr>
                        <tr class="dynamic-print-row">

                            <td class="title">

                                Coating Price

                            </td>

                            <td>

                                <input id="coating_price" name="coating_price" class="numeric-only" disabled>

                            </td>
                            <td class="title discount-title" id="charger_discount_title">
                                Charger Swapping Discount
                            </td>

                            <td class="discount-value" id="charger_discount_cell">
                                <input type="text" id="charger_swapping_discount" name="charger_swapping_discount"
                                    class="numeric-only" placeholder="0.00" disabled>
                            </td>
                        </tr>
                        <tr>

                            <td class="title">

                                PPF

                            </td>

                            <td>

                                <input id="ppf" name="ppf" class="numeric-only">

                            </td>


                        </tr>

                        <tr>

                            <td class="title">

                                RTO Yellow Tape

                            </td>

                            <td>

                                <input id="rto_yellow_tape" name="rto_yellow_tape" class="numeric-only">

                            </td>
                        </tr>
                        <tr class="dynamic-print-row">

                            <td class="title">

                                Kazam Charging Kit

                            </td>

                            <td>

                                <input id="kazam_charging_kit" name="kazam_charging_kit" class="numeric-only">

                            </td>

                        </tr>

                        <tr class="dynamic-print-row">

                            <td class="title">

                                Incidental Charges

                            </td>

                            <td>

                                <input id="incidental_charges" name="incidental_charges" class="numeric-only">

                            </td>
                        </tr>
                        <tr>

                            <td class="title">

                                Shield

                            </td>

                            <td>

                                <select id="shield" name="shield">

                                    <option value="">Select</option>

                                    <option value="4th Year">

                                        4th Year

                                    </option>

                                    <option value="4th + 5th Year">

                                        4th + 5th Year

                                    </option>

                                    <option value="No Shield">

                                        No Shield

                                    </option>

                                </select>

                            </td>

                        </tr>

                        <tr class="dynamic-print-row">

                            <td class="title">

                                Shield Price

                            </td>

                            <td>

                                <input id="shield_price" name="shield_price" class="numeric-only" disabled>

                            </td>
                        </tr>
                        <tr>

                            <td class="title">

                                RSA

                            </td>

                            <td>

                                <select id="rsa" name="rsa">

                                    <option value="">Select</option>

                                    <option>1 Year</option>
                                    <option>2 Year</option>
                                    <option>3 Year</option>
                                    <option>4 Year</option>
                                    <option>5 Year</option>
                                    <option>No RSA</option>

                                </select>

                            </td>

                        </tr>

                        <tr class="dynamic-print-row">

                            <td class="title">

                                RSA Amount

                            </td>

                            <td>

                                <input id="rsa_amount" name="rsa_amount" class="numeric-only" disabled>

                            </td>
                        </tr>
                        <tr>

                            <td class="title">

                                Fastag

                            </td>

                            <td>

                                <input id="fastag" name="fastag" class="numeric-only">

                            </td>

                        </tr>

                        <tr>

                            <td class="title">

                                COD Charges

                            </td>

                            <td>

                                <input id="cod_charges" name="cod_charges" class="numeric-only">

                            </td>
                        </tr>
                        <tr class="dynamic-print-row">
                            <td class="title">

                                TCS @1% (Auto Calculated)

                            </td>

                            <td>

                                <input id="tcs" name="tcs" class="numeric-only" readonly>

                            </td>

                        </tr>

                        <tr class="dynamic-print-row">

                            <td class="title">

                                Charger Swapping

                            </td>

                            <td>

                                <select id="charger_swapping" name="charger_swapping">

                                    <option value="">Select</option>
                                    <option value="N/A">N/A</option>
                                    <option value="NCH to 7.2 kW">NCH to 7.2 kW</option>
                                    <option value="NCH to 11.2 kW">NCH to 11.2 kW</option>
                                    <option value="7.2 kW to 11.2 kW">7.2 kW to 11.2 kW</option>

                                </select>

                            </td>
                        </tr>
                        <tr class="dynamic-print-row">

                            <td class="title">

                                Charger Swapping Amount

                            </td>

                            <td>

                                <input id="charger_swapping_amount" name="charger_swapping_amount" class="numeric-only"
                                    disabled>

                            </td>

                        </tr>

                        <tr style="background:#f2f2f2;font-weight:bold;">

                            <td>

                                TOTAL RECEIVABLE

                            </td>

                            <td>

                                <input id="total_receivable" name="total_receivable" readonly>

                            </td>

                            <td>

                                TOTAL DISCOUNT

                            </td>

                            <td>

                                <input id="total_discount_amount" readonly>

                                <input type="hidden" id="total_discount" name="total_discount">

                            </td>

                        </tr>
                        <tr style="background:#198754;
                            color:#fff;
                            font-weight:bold;">

                            <td colspan="3">

                                ON ROAD PRICE

                            </td>

                            <td>

                                <input id="net_receivable_summary" name="net_receivable_summary" readonly>

                            </td>

                        </tr>

                    </table>
                    <table class="bill-table note-box flex-grow-1">


                        <tr>

                            <td>

                                <div style="font-weight:bold; font-size:8px; margin-bottom:3px;">
                                    NOTE:
                                </div>

                                <p style="
                                font-size:7px;
                                font-weight:bold;
                                line-height:1.3;
                                text-align:justify;
                                margin:0;
                                ">

                                    <b>1.</b> Vehicle shall be delivered only against payment.
                                    <b>2.</b> Interest shall be charged @ 24% P.A. in case of payments delayed over
                                    three
                                    days.
                                    <b>3.</b> No Interest shall be payable on Booking Amount.
                                    <b>4.</b> Price & Scheme of the vehicle is applicable as on the date of delivery.
                                    Price
                                    & Scheme are subjected to change without any prior notice.
                                    <b>5.</b> Self attested coloured copy of original documents is required for any
                                    claim.
                                    Claims will be rejected in absence of original documents.

                                </p>



                            </td>

                        </tr>

                    </table>

                </div>

            </div>


    </div>
</div>
</div>

<div class="card-footer text-end mt-3 no-print">
    <button type="button" class="btn btn-primary no-print" onclick="printQuotation();">

        <i class="la la-print"></i>

        Print / Save PDF

    </button>
    <button type="submit" class="btn btn-success">
        <i class="la la-save"></i> Save Quotation
    </button>

    <a href="{{ backpack_url('quotation-form') }}" class="btn btn-secondary">
        Cancel
    </a>
</div>
</form>

</div>
</div>

@endsection

@push('after_scripts')
{{--
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet"> --}}
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


<script>
    $(document).on('input', '.numeric-only', function () {

    let value = $(this).val();

    // Allow only digits and one decimal
    value = value.replace(/[^\d.]/g, '');
    value = value.replace(/(\..*)\./g, '$1');

    $(this).val(value);

});
    function updateAccessoriesAmount() {

    let total = 0;

    $('#accessories option:selected').each(function () {

        total += parseFloat($(this).data('price')) || 0;

    });

    $('#accessories_amount').val(total.toFixed(2));

    calculateQuotation();

}

function updateAccessoriesPrintText() {

    let list = [];

    $('#accessories option:selected').each(function () {
        list.push($(this).text());
    });

    $('#accessories_print').text(list.join(', '));
}

$('#accessories').on(
    'change',
    function () {
        updateAccessoriesAmount();
        updateAccessoriesPrintText();
    }
);

$(document).ready(function () {
    updateAccessoriesPrintText();
});

$(document).ready(function () {

    updateAccessoriesAmount();

});

$('#coating').on('change', function () {

    if ($(this).val() === '') {

        $('#coating_price')
            .val('')
            .prop('disabled', true);

    }
    else if ($(this).val() === 'No Coating') {

        $('#coating_price')
            .val('N/A')
            .prop('disabled', true);

    }
    else {

        $('#coating_price')
            .val('')
            .prop('disabled', false)
            .focus();

    }

    calculateQuotation();

});

// Page load par bhi apply ho jaye
$('#coating').trigger('change');

$('#shield').on('change', function () {

    if ($(this).val() === '') {

        $('#shield_price')
            .val('')
            .prop('disabled', true);

    }
    else if ($(this).val() === 'No Shield') {

        $('#shield_price')
            .val('N/A')
            .prop('disabled', true);

    }
    else {

        $('#shield_price')
            .val('')
            .prop('disabled', false)
            .focus();

    }

    calculateQuotation();

});

// Initial state
$('#shield').trigger('change');

$('#rsa').on('change', function () {

    if ($(this).val() === '') {

        $('#rsa_amount')
            .val('')
            .prop('disabled', true);

    }
    else if ($(this).val() === 'No RSA') {

        $('#rsa_amount')
            .val('N/A')
            .prop('disabled', true);

    }
    else {

        $('#rsa_amount')
            .val('')
            .prop('disabled', false)
            .focus();

    }

    calculateQuotation();

});

// Initial state
$('#rsa').trigger('change');

$('#charger_swapping').on('change', function () {

        if (
        $(this).val() === '' ||
        $(this).val() === 'N/A'
    ) {

        $('#charger_swapping_amount')
            .val('N/A')
            .prop('disabled', true);

        $('#charger_swapping_discount')
            .val('N/A')
            .prop('disabled', true);

    } else {

        $('#charger_swapping_amount')
            .val('')
            .prop('disabled', false)
            .focus();

        $('#charger_swapping_discount')
            .val('')
            .prop('disabled', false);

    }

    calculateQuotation();

});

// Initial state
$('#charger_swapping').trigger('change');



function num(id) {

    let value = $('#' + id).val();

    if (value === 'N/A' || value === '' || value == null) {
        return 0;
    }

    return parseFloat(value) || 0;

}

function calculateQuotation() {

    // Total Receivable
    let subtotal =
        num('ex_showroom_price') +
        num('accessories_amount') +
        num('maxicare') +
        num('vltd_device') +
        num('coating_price') +
        num('ppf') +
        num('rto_yellow_tape') +
        num('kazam_charging_kit') +
        num('incidental_charges') +
        num('shield_price') +
        num('rsa_amount') +
        num('fastag') +
        num('cod_charges') +
        num('charger_swapping_amount');
    
        let tcs = 0;

        if (subtotal > 1000000) {

            tcs = subtotal * 0.01;

            $('#tcs')
                .val(tcs.toFixed(2))
                .prop('readonly', true)
                .prop('disabled', false);

        } else {

            $('#tcs')
                .val('N/A')
                .prop('readonly', true)
                .prop('disabled', true);
        }
    let totalReceivable = subtotal + tcs;


    $('#total_receivable').val(totalReceivable.toFixed(2));

    // Total Discount
    let totalDiscount =
        num('oem_scheme_discount') +
        num('fame_subsidy') +
        num('exchange_bonus') +
        num('corporate_discount') +
        num('accessories_discount') +
        num('ceramic_discount') +
        num('ppf_discount') +
        num('dealer_discount') +
        num('charger_swapping_discount');

    let discount = totalDiscount.toFixed(2);

$('#total_discount_amount').val(discount);
$('#total_discount').val(discount);


    // Net Receivable
    let netReceivable = totalReceivable - totalDiscount;

    $('#net_receivable_summary').val(netReceivable.toFixed(2));
    
}

// Recalculate whenever any input changes
$(document).on(
    'keyup change',
    '#ex_showroom_price,' +
    '#accessories_amount,' +
    '#maxicare,' +
    '#vltd_device,' +
    '#coating_price,' +
    '#ppf,' +
    '#rto_yellow_tape,' +
    '#kazam_charging_kit,' +
    '#incidental_charges,' +
    '#shield_price,' +
    '#rsa_amount,' +
    '#fastag,' +
    '#cod_charges,' +
    '#charger_swapping_amount,' +
    '#tcs,' +
    '#oem_scheme_discount,' +
    '#fame_subsidy,' +
    '#exchange_bonus,' +
    '#corporate_discount,' +
    '#accessories_discount,' +
    '#ceramic_discount,' +
    '#ppf_discount,' +
    '#dealer_discount,' +
    '#charger_swapping_discount',
    calculateQuotation
);

// Accessories selection change
$('#accessories').on('change', function () {
    updateAccessoriesAmount();
    calculateQuotation();
});

// Initial calculation
$(document).ready(function () {
    calculateQuotation();
});
$(document).ready(function () {

    $('#accessories').select2({

        placeholder: 'Select Accessories',

        width: '100%',

        closeOnSelect: false

    });
    console.log('Discount field:', document.getElementById('total_discount'));
console.log('Net field:', document.getElementById('net_receivable_summary'));

console.log('Discount value:', $('#total_discount').val());
console.log('Net value:', $('#net_receivable_summary').val());

});

// Segment -> Model



// Model -> Variant





function toggleLMMFields() {

    let isLMM = "{{ optional($selectedEnquiry)->segment_code }}" === "LMM";

    const fields = [
        '#kazam_charging_kit',
        '#incidental_charges',
        '#charger_swapping',
        '#fame_subsidy'
    ];

    fields.forEach(function (field) {

        $(field).prop('disabled', !isLMM);

        if (!isLMM) {
            $(field).val('N/A');
        } else {
            $(field).val('');
        }

    });

    // Charger Swapping Amount
    if (!isLMM) {

        $('#charger_swapping')
            .val('N/A')
            .prop('disabled', true);

        $('#charger_swapping_amount')
            .val('N/A')
            .prop('disabled', true);

        $('#charger_swapping_discount')
            .val('N/A')
            .prop('disabled', true);

    } else {

        $('#charger_swapping')
            .val('')
            .prop('disabled', false);

        $('#charger_swapping_amount')
            .val('')
            .prop('disabled', true);

        $('#charger_swapping_discount')
            .val('')
            .prop('disabled', true);

    }

    calculateQuotation();
}
$(document).ready(function () {

    toggleLMMFields();

});
function printQuotation() {

    $('.discount-value').each(function () {

        let input = $(this).find('input');
        let value = (input.val() || '').trim();

        if (
            value === '' ||
            value === '0' ||
            value === '0.00' ||
            value === 'N/A'
        ) {
            $(this).hide();
            $(this).prev('.discount-title').hide();
        }

    });

    $('.dynamic-print-row').each(function () {

        let hideRow = true;

        $(this).find('input, select').each(function () {

            let value = $(this).val();

            if (
                value !== '' &&
                value !== 'N/A' &&
                value !== '0' &&
                value !== '0.00'
            ) {
                hideRow = false;
            }

        });

        if (hideRow) {
            $(this).hide();
        }

    });
    let tcs = $('#tcs').val();

    if (
        tcs === '' ||
        tcs === '0' ||
        tcs === '0.00' ||
        tcs === 'N/A'
    ) {
        $('#tcs').closest('tr').hide();
    }

    window.print();
    $('#tcs').closest('tr').show();

    $('.dynamic-print-row').show();
    $('.discount-title').show();
    $('.discount-value').show();
}


</script>
@endpush