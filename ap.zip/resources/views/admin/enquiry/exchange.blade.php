@extends(backpack_view('blank'))

@section('header')
    <section class="container-fluid"></section>
@endsection

@push('after_styles')
    <link rel="stylesheet" href="https://unpkg.com/ag-grid-community/styles/ag-theme-quartz.css">
    <style>
        .ag-theme-quartz .center-header .ag-header-cell-label,
        .ag-theme-quartz .ag-header-cell-label {
            justify-content: center !important;
            text-align: center !important;
        }

        .ag-cell.action-cell {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            white-space: nowrap !important;
            padding: 0 10px !important;
        }

        .ag-cell.action-cell .btn {
            white-space: nowrap !important;
            width: max-content !important;
        }
    </style>
@endpush

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-gradient-primary d-flex justify-content-between align-items-center">
                    <h2 class="card-title mb-0 fw-bold text-black text-nowrap">
                        {{ isset($title) ? trim(explode('(', $title)[0]) : 'Exchange List' }}
                    </h2>
                </div>
                <div class="card-body p-0" style="background:#f8fafc">
                    <div
                        class="d-flex justify-content-between align-items-center flex-wrap gap-2 p-3 border-bottom bg-white">
                        <div class="d-flex align-items-center gap-2">
                            <input type="text" id="quickFilter" class="form-control" style="width:360px;"
                                placeholder="Smart Search...">
                        </div>
                    </div>
                    <!-- GRID CONTAINER WITH LOADER WRAPPER -->
                    <div style="position: relative;">
                        <div id="gridLoader"
                            style="display:none; position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(255,255,255,0.7); z-index: 1000; justify-content: center; align-items: center;">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </div>
                        <div id="myGrid" class="ag-theme-quartz" style="height: calc(93vh - 200px); width:100%;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('after_scripts')
    <script src="https://unpkg.com/ag-grid-community/dist/ag-grid-community.min.js"></script>
    <script>
        const ALL_COLUMNS = @json($gridConfig['columns'] ?? []);
        const LIST_TYPE = @json($gridConfig['list_type'] ?? 'exchange');
        let gridApi;
        let currentSearchText = '';

        function getCols(fields) {
            return ALL_COLUMNS.filter(col => fields.includes(col.field));
        }

        const DEFAULT_VISIBLE_FIELDS = [
            'serial_no',
            'x8_enquiry_no',
            'x8_enquiry_date',
            'first_name',
            'mobile',
            'model_name',
            'variant_name',
            'consid_brand',
            'consid_model',
            'purchase_type',
            'expected_price',
            'offered_price',
            'exchange_bonus',
            'price_gap',
            'dms_enquiry_stage',
            'action'
        ];

        const columnGroups = [{
                headerName: 'Enquiry Details',
                headerClass: 'ag-header-center',
                children: getCols(['serial_no', 'x8_enquiry_no', 'x8_enquiry_date']).map(c => {
                    c.pinned = 'left';
                    return c;
                })
            },
            {
                headerName: 'Customer',
                headerClass: 'ag-header-center',
                children: getCols(['first_name', 'mobile'])
            },
            {
                headerName: 'Vehicle Info',
                headerClass: 'ag-header-center',
                children: getCols(['model_name', 'variant_name'])
            },
            {
                headerName: 'Exchange Detail',
                headerClass: 'ag-header-center',
                children: getCols(['consid_brand', 'consid_model', 'purchase_type', 'expected_price', 'offered_price',
                    'exchange_bonus', 'price_gap', 'dms_enquiry_stage', 'sc_code'
                ])
            },
            {
                headerName: 'Action',
                headerClass: 'ag-header-center',
                children: getCols(['action']).map(col => {
                    col.pinned = 'right';
                    col.cellRenderer = 'htmlRenderer';
                    col.autoHeight = true;
                    col.cellClass = 'action-cell';
                    col.suppressSizeToFit = true;
                    delete col.width;
                    return col;
                })
            }
        ];

        const dataSource = {
            getRows: function(params) {
                if (gridApi) {
                    gridApi.showLoadingOverlay();
                }

                fetch('{{ backpack_url('enquiries/data') }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({
                            startRow: params.startRow,
                            endRow: params.endRow,
                            sortModel: params.sortModel,
                            filterModel: params.filterModel,
                            searchText: currentSearchText,
                            list_type: LIST_TYPE
                        })
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (loader) loader.style.display = 'none';
                        params.successCallback(data.rows || [], data.lastRow ?? 0);

                        // Auto-size the action column dynamically based on rendered buttons
                        setTimeout(() => {
                            if (gridApi) {
                                gridApi.autoSizeColumns(['action']);
                            }
                        }, 100); // 100ms delay gives the browser time to paint the HTML buttons
                    })
                    .catch(err => {
                        if (gridApi) {
                            gridApi.hideLoadingOverlay();
                        }
                        console.error('Failed to load exchange enquiries', err);
                        params.failCallback();
                    });
            }
        };

        const gridOptions = {
            columnDefs: columnGroups,
            rowModelType: 'infinite',
            datasource: dataSource,
            pagination: true,
            paginationPageSize: 50,
            cacheBlockSize: 50,
            rowHeight: 35,
            defaultColDef: {
                sortable: true,
                filter: true,
                resizable: true,
                cellStyle: {
                    textAlign: 'center'
                }
            },
            components: {
                htmlRenderer: params => params.value || ''
            },
            onGridReady: params => {
                gridApi = params.api;
                const allFields = [];
                columnGroups.forEach(g => {
                    if (g.children) g.children.forEach(c => allFields.push(c.field))
                });
                gridApi.setColumnsVisible(allFields, false);
                gridApi.setColumnsVisible(DEFAULT_VISIBLE_FIELDS, true);
                setTimeout(() => gridApi.autoSizeColumns(gridApi.getAllDisplayedColumns().map(c => c.getColId()),
                    false), 400);
            }
        };

        function debounce(fn, delay) {
            let timer;
            return (...args) => {
                clearTimeout(timer);
                timer = setTimeout(() => fn(...args), delay);
            };
        }

        document.addEventListener('DOMContentLoaded', () => {
            gridApi = agGrid.createGrid(document.querySelector('#myGrid'), gridOptions);

            document.getElementById('quickFilter')?.addEventListener('input', debounce(e => {
                currentSearchText = e.target.value.trim();
                if (gridApi) {
                    gridApi.showLoadingOverlay();
                }
                gridApi.setGridOption('datasource', {
                    ...dataSource
                });
            }, 400));
        });
    </script>
@endpush
